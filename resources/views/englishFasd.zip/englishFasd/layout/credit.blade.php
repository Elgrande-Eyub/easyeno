<div class="sub-footer pt-40 pb-40 bord-thin-top ontop">
    <div class="container">
        <div class="row" style="align-items: center">
            <div class="col-lg-4">
                <div class="logo">
                    <a href="{{ route('index-en') }}">
                        <img style="width: 150%"  src="assets/imgs/logo/white/easyenoLogoBanner.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="copyright d-flex">
                    <div class="ml-auto">
                        <p class="fz-13">© 2023 EASYENO MEDIA is Proudly Powered by <span
                                class="underline"><a href="#"
                                    target="_blank">EYUB</a></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
