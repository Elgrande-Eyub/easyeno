<div class="loader-wrap">
    <svg viewBox="0 0 1000 1000" preserveAspectRatio="none">
        <path id="svg" d="M0,1005S175,995,500,995s500,5,500,5V0H0Z"></path>
    </svg>

    <div class="loader-wrap-heading">
        <div class="load-text">
            <span>E</span>
            <span>A</span>
            <span>S</span>
            <span>Y</span>
            <span>E</span>
            <span>N</span>
            <span>O</span>
            <span>M</span>
            <span>E</span>
            <span>D</span>
            <span>I</span>
            <span>A</span>
        </div>
    </div>
</div>
