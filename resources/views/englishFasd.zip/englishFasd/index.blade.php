<!DOCTYPE html>
<html lang="zxx">


<head>
    <!-- Title  -->
    <title>EASYENO Media | Your Partner in Innovative Marketing Solutions</title>
    <meta name="description" content="EASYENO Media is a leading marketing agency committed to delivering creative and results-driven solutions. Explore our services in digital marketing, SEO, social media, and more. Transform your online presence with EASYENO Media.">
    @include('english.layout.head')
</head>

<body class="home-main-crev main-bg">



    <!-- ==================== Start Loading ==================== -->

    @include('english.layout.loading')

    <!-- ==================== End Loading ==================== -->


    <div class="cursor"></div>


    <!-- ==================== Start progress-scroll-button ==================== -->

    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>

    <!-- ==================== End progress-scroll-button ==================== -->



    <div id="smooth-wrapper">

        <!-- ==================== Start Navbar ==================== -->

        @include('english.layout.header')
        <!-- ==================== End Navbar ==================== -->

        <div id="smooth-content">

            <main class="main-bg" >

                <!-- ==================== Start Slider ==================== -->
                <header class="header-startup  full-height valign bg-img parallaxie container1" data-background="#" data-overlay-dark="7" style="background-image: url(&quot;assets/imgs/background/14.jpg&quot;); background-size: cover; background-repeat: no-repeat; background-attachment: fixed; background-position: center 0px; translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
                    <video autoplay loop muted plays-inline class="background-clip">
                        <source src="{{ asset('backgorund-Video.mp4') }}" type="video/mp4">
                    </video>
                    <div class="container ontop" style="translate: none; rotate: none; scale: none; opacity: 1; transform: translate(0px, 0px);">
                        <div class="row justify-content-center">
                            <div class="col-lg-11">
                                <div class="caption text-center mt-50">
                                    <div class="sec-lg-head">
                                        <h6 class="dot-titl colorbg-3 mb-10">Marketing Agency</h6>
                                    </div>
                                    <h1 class="fw-700 fz-80">
                                        <h1 class="fw-700 fz-80">We're<img  style="width:10%;" src="{{ asset('assets/imgs/logo/white/esaynoLogo.png') }}" alt="Easyeno Media Logo">sharp brand
                                        <h4 style="margin-top: 1rem">Your Gateway to Exceptional Marketing Strategies</h4>
                                        <h6 class="stroke">With EASYENO MEDIA</h6>
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="arrow-down main-bg">
                        <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg" class="svg-for-tablet">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M0.835489 6.51022L15.5607 6.51022L10.9081 1.85764C10.5179 1.46747 10.9555 1.24491 11.3626 0.837776C11.7697 0.430646 11.9923 -0.00687319 12.3825 0.383293L18.7406 6.74141C19.1307 7.13158 19.117 7.77791 18.7099 8.18504L12.0753 14.8196C11.6682 15.2267 11.371 14.7053 11.0739 14.4081C10.7767 14.111 10.2553 13.8138 10.6624 13.4067L15.5173 8.55182L0.792051 8.55182L0.835489 6.51022Z" fill="currentColor"></path>
                        </svg>
                    </div>
                    <div class="bg-pattern-half bg-img opacity-5" data-background="{{ asset('assets/imgs/svg-assets/patern-bg.png') }}" style="background-image: url(&quot;assets/imgs/svg-assets/patern-bg.png&quot;);"></div>
                </header>



                <!-- ==================== End Slider ==================== -->



                <!-- ==================== Start about ==================== -->
                <section class="about-intro section-padding">
                    <div class="container">
                        <div class="row mb-80 rtl">
                            <div class="col-lg-5">
                                <div class="sec-lg-head md-mb30">
                                    <h6 class="dot-titl colorbg-3 mb-10 wow fadeIn">Why Choose Us</h6>
                                    <h2 class="d-rotate wow">
                                        <span class="rotate-text">Get to Know Us Up Close</span>
                                    </h2>
                                </div>
                            </div>
                            <div class="col-lg-5 offset-lg-2 valign">
                                <div class="text">
                                    <p class="d-slideup wow">
                                        <span class="sideup-text">
                                            <span class="up-text">Choosing us saves you the search for marketing ideas, product presentation methods, and how to target your audience.</span>
                                        </span>
                                    </p>
                                    <div class="vew-all mt-50 ml-30 wow fadeIn" data-wow-delay=".8s">
                                        <a href="{{ route('about-en') }}">Meet our team
                                            <span>
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.6120 12.2344 13.5002 12.2344C13.3883 12.2344 13.2810 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.7170 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.2830 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.6120 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.9220 4.38811 13.9220 4.5Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-lg-5 valign rest ">
                                <div class="cont" style="margin-right: 1rem">
                                    <h1 class="d-rotate wow">
                                        <span class="stroke rotate-text">Your Ideal Tech Partner</span>
                                    </h1>
                                    <div class="feat mt-80" style="padding:0.5rem">
                                        <div class="item-flex d-flex align-items-center mb-50 wow fadeIn" data-wow-delay=".4s">
                                            <div>
                                                <div class="icon-img-50">
                                                    <img src="{{ asset('assets/imgs/serv-icons/0.png') }}" alt="">
                                                </div>
                                            </div>
                                            <div class="cont mr-30">
                                                <h6>Time</h6>
                                                <p class="fz-15">We specialize in marketing, saving you valuable time and resources, making us your ideal choice.</p>
                                            </div>
                                        </div>
                                        <div class="item-flex d-flex align-items-center mb-50 wow fadeIn" data-wow-delay=".4s">
                                            <div>
                                                <div class="icon-img-50">
                                                    <img src="{{ asset('assets/imgs/serv-icons/0.png') }}" alt="">
                                                </div>
                                            </div>
                                            <div class="cont mr-30">
                                                <h6>Quality</h6>
                                                <p class="fz-15">We turn your ideas into reality within a marketing strategy to grow your business and stay ahead of competitors.</p>
                                            </div>
                                        </div>
                                        <div class="item-flex d-flex align-items-center wow fadeIn" data-wow-delay=".8s">
                                            <div>
                                                <div class="icon-img-50">
                                                    <img src="{{ asset('assets/imgs/serv-icons/1.png') }}" alt="">
                                                </div>
                                            </div>
                                            <div class="cont mr-30">
                                                <h6>Budget</h6>
                                                <p class="fz-15">Our high-quality financial management ensures your budget is a successful investment.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 rest">
                                <div class="imgs md-mb50">
                                    <div class="img1">
                                        <div class="o-hidden">
                                            <div class="imago wow">
                                                <img  src="{{ asset('assets\imgs\index\about\Target.png') }}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="img2">
                                        <div class="o-hidden">
                                            <div class="imago wow">
                                                <img  src="{{ asset('assets\imgs\index\about\Rocket.png') }}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <!-- ==================== End about ==================== -->



                <!-- ==================== Start marq ==================== -->

                <section class="marquee">
                    <div class="container-fluid rest">
                        <div class="row">
                            <div class="col-12">
                                <div class="main-marq">
                                    <div class="slide-har st1">
                                        <div class="box non-strok">
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Brand Identity and Design</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Website and Application Development</span> <span
                                                        class="fz-50 ml-50 stroke icon">*</span></h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Digital Marketing</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Advertising Campaigns</span> <span
                                                        class="fz-50 ml-50 stroke icon">*</span></h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Marketing Videos</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Social Media Management</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                        </div>
                                        <div class="box non-strok">
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Brand Identity and Design</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Website and Application Development</span> <span
                                                        class="fz-50 ml-50 stroke icon">*</span></h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Digital Marketing</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Advertising Campaigns</span> <span
                                                        class="fz-50 ml-50 stroke icon">*</span></h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Marketing Videos</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                            <div class="item">
                                                <h4 class="d-flex align-items-center"><span>Social Media Management</span>
                                                    <span class="fz-50 ml-50 stroke icon">*</span>
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ==================== End marq ==================== -->


                <!-- ==================== Start Services ==================== -->

                <section class="serv-box section-padding pb-0 rtl">
                    <div class="container">
                        <div class="sec-lg-head mb-80">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="position-re">
                                        <h6 class="dot-titl colorbg-3 mb-10 wow fadeIn">Special Services</h6>
                                        <h2 class="d-rotate wow">
                                            <span class="rotate-text">EASYENO Services</span>
                                        </h2>
                                    </div>
                                </div>
                                <div class="col-lg-4 d-flex align-items-center">
                                    <div class="text wow fadeIn">
                                        <p>Here begins your project journey, where experience becomes a game-changer.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="serv-item lg-pad md-mb50 radius-5 wow fadeIn" data-wow-delay=".5s">
                                    <div class="icon-img-50 mb-40">
                                        <img src="assets/imgs/serv-icons/0.png" alt="">
                                    </div>
                                    <span class="mb-10 opacity-7">Product Design</span>
                                    <h6 class="mb-15">Digital Marketing</h6>
                                    <p class="fz-14">Digital marketing to increase your online presence and reach a global audience.</p>
                                    <div class="crv-more">
                                        <a href="#" class="mt-30 ls1 fz-12 text-u" >Read More<svg
                                            width="18" height="18" viewBox="0 0 18 18" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.6120 12.2344 13.5002 12.2344C13.3883 12.2344 13.2810 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.7170 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.2830 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.6120 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.9220 4.38811 13.9220 4.5Z"
                                                fill="currentColor"></path>
                                        </svg></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="serv-item lg-pad md-mb50 radius-5 wow fadeIn" data-wow-delay=".8s">
                                    <div class="icon-img-50 mb-40">
                                        <img src="assets/imgs/serv-icons/1.png" alt="">
                                    </div>
                                    <span class="mb-10 opacity-7">Custom Services</span>
                                    <h6 class="mb-15">Visual Identity Crafting</h6>
                                    <p class="fz-14">For brands and designs that create a lasting impression and align with your brand's essence.</p>
                                    <div class="crv-more">
                                        <a href="#" class="mt-30 ls1 fz-12 text-u" >Read More<svg
                                            width="18" height="18" viewBox="0 0 18 18" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.6120 12.2344 13.5002 12.2344C13.3883 12.2344 13.2810 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.7170 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.2830 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.6120 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.9220 4.38811 13.9220 4.5Z"
                                            fill="currentColor"></path>
                                        </svg></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="serv-item lg-pad radius-5 wow fadeIn" data-wow-delay="1.2s">
                                    <div class="icon-img-50 mb-40">
                                        <img src="assets/imgs/serv-icons/2.png" alt="">
                                    </div>
                                    <span class="mb-10 opacity-7">Product Development</span>
                                    <h6 class="mb-15">Creative Content Crafting</h6>
                                    <p class="fz-14">Our creative team excels in writing, directing, and editing creative content using the latest technologies and innovative ideas to create lasting memories for the audience.</p>
                                    <div class="crv-more">
                                        <a href="#" class="mt-30 ls1 fz-12 text-u" >Read More<svg
                                            width="18" height="18" viewBox="0 0 18 18" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.6120 12.2344 13.5002 12.2344C13.3883 12.2344 13.2810 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.2830 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.6120 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.9220 4.38811 13.9220 4.5Z"
                                            fill="currentColor"></path>
                                        </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="works thecontainer">
                    <div class="panel mt-30">
                        <div class="item">
                            <div class="img" style="text-align: center">
                                <img src="{{ asset('assets\imgs\index\services\branding.png') }}" alt="">
                            </div>
                            <div class="cont d-flex align-items-center">
                                <div>
                                    <span>We professionally design your brand identity to reflect your vision and business aspirations.</span>
                                    <h5>Visual Identity Crafting</h5>
                                </div>
                            </div>
                            <a href="#0" class="link-overlay"></a>
                        </div>
                    </div>

                    <div class="panel mt-30">
                        <div class="item">
                            <div class="img">
                                <img src="{{ asset('assets\imgs\index\services\socialMedia.png') }}" alt="">
                            </div>
                            <div class="cont d-flex align-items-center">
                                <div>
                                    <span >We handle social media accounts and manage their content in the appropriate manner.</span>
                                    <h5>Social Media Account Management</h5>
                                </div>
                            </div>
                            <a href="#0" class=" link-overlay"></a>
                        </div>
                    </div>

                    <div class="panel mt-30">
                        <div class="item">
                            <div class="img">
                                <img src="{{ asset('assets\imgs\index\services\websiteCreation.png') }}" alt="">
                            </div>
                            <div class="cont d-flex align-items-center">
                                <div>
                                    <span>We design websites that suit your needs, making it easier for people to get to know you.</span>
                                    <h5>Websites</h5>
                                </div>
                            </div>
                            <a href="#0" class="link-overlay"></a>
                        </div>
                    </div>

                    <div class="panel mt-30">
                        <div class="item">
                            <div class="img">
                                <img src="{{ asset('assets\imgs\index\services\digitalMarketing.png') }}" alt="">
                            </div>
                            <div class="cont d-flex align-items-center">
                                <div>
                                    <span>When your goal is to reach your real customers, our team is your first choice for your goal.</span>
                                    <h5>Digital Marketing</h5>
                                </div>
                            </div>
                            <a href="#0" class="link-overlay"></a>
                        </div>
                    </div>

                    <div class="panel mt-30">
                        <div class="item">
                            <div class="img">
                                <img src="{{ asset('assets\imgs\index\services\videoMarketing.png') }}" alt="">
                            </div>
                            <div class="cont d-flex align-items-center">
                                <div>
                                    <span>We innovate and skillfully build creative content, making us the ideal partner for you in this field.</span>
                                    <h5>Creative Content Crafting</h5>
                                </div>
                            </div>
                            <a href="#0" class="link-overlay"></a>
                        </div>
                    </div>
                </section>


                <section class="intro-corp section-padding sub-bg ">
                    <div class="container">
                        <div class="row lg-marg">
                            <div class="col-lg-6 md-mb50">
                                <div class="imgs mb-80">
                                    <div class="img1 main-color3 wow fadeIn" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeIn;">
                                        <img src="{{ asset('assets/imgs/index/company/company1.png') }}" alt="Company Image 1">
                                    </div>
                                    <div class="img2 wow fadeInLeft" style="box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
                                        <img src="{{ asset('assets/imgs/index/company/company.png') }}" alt="Company Image 2">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 valign">
                                <div class="cont">
                                    <div class="sec-lg-head mb-80 wow fadeIn">
                                        <h6 class="dot-titl colorbg-3 mb-10">About the Company</h6>
                                    </div>
                                    <h3 class="mb-15">Witness the Creative Process Behind Our <span class="stroke fw-700 opacity-7">Digital Marketing</span>.</h3>
                                    <p>We produce outstanding digital work for the web, and experiences with both creative agencies and global brands alike - passionately.</p>
                                    <div class="mt-50 pt-30 bord-thin-top">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <ul class="rest list-arrow">
                                                    <li class="mt-20">
                                                        <span class="icon">
                                                            <svg width="100%" height="100%" viewBox="0 0 9 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.71108 3.78684L8.22361 4.29813L7.71263 4.80992L4.64672 7.87832L4.13433 7.36688L6.87531 4.62335H1.11181H0.750039H0.388177L0.382812 0.718232H1.10645L1.11082 3.90005H6.80113L4.12591 1.22972L4.63689 0.718262L7.71108 3.78684Z" fill="#fff"></path>
                                                            </svg>
                                                        </span>
                                                        <span>Marketing Strategy</span>
                                                    </li>
                                                    <li class="mt-20">
                                                        <span class="icon">
                                                            <svg width="100%" height="100%" viewBox="0 0 9 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.71108 3.78684L8.22361 4.29813L7.71263 4.80992L4.64672 7.87832L4.13433 7.36688L6.87531 4.62335H1.11181H0.750039H0.388177L0.382812 0.718232H1.10645L1.11082 3.90005H6.80113L4.12591 1.22972L4.63689 0.718262L7.71108 3.78684Z" fill="#fff"></path>
                                                            </svg>
                                                        </span>
                                                        <span>Brand Redesign</span>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <ul class="rest list-arrow">
                                                    <li class="mt-20">
                                                        <span class="icon">
                                                            <svg width="100%" height="100%" viewBox="0 0 9 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.71108 3.78684L8.22361 4.29813L7.71263 4.80992L4.64672 7.87832L4.13433 7.36688L6.87531 4.62335H1.11181H0.750039H0.388177L0.382812 0.718232H1.10645L1.11082 3.90005H6.80113L4.12591 1.22972L4.63689 0.718262L7.71108 3.78684Z" fill="#fff"></path>
                                                            </svg>
                                                        </span>
                                                        <span>Unique Production</span>
                                                    </li>
                                                    <li class="mt-20">
                                                        <span class="icon">
                                                            <svg width="100%" height="100%" viewBox="0 0 9 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.71108 3.78684L8.22361 4.29813L7.71263 4.80992L4.64672 7.87832L4.13433 7.36688L6.87531 4.62335H1.11181H0.750039H0.388177L0.382812 0.718232H1.10645L1.11082 3.90005H6.80113L4.12591 1.22972L4.63689 0.718262L7.71108 3.78684Z" fill="#fff"></path>
                                                            </svg>
                                                        </span>
                                                        <span>Company Identity</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="{{ route('about-en') }}" class="butn butn-md butn-bord radius-30 mt-50">
                                        <span>Explore More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="pricing section-padding sub-bg ">
                    <div class="container">
                        <div class="sec-lg-head mb-80">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="position-re">
                                        <h6 class="dot-titl colorbg-3 mb-10">Featured Services</h6>
                                        <h2 class="fz-60 fw-700">Our Prices</h2>
                                    </div>
                                </div>
                                <div class="col-lg-4 d-flex align-items-center">
                                    <div class="text">
                                        <p>We look forward to tackling challenges that elevate us to a different creative level, achieving tangible results.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row md-marg">
                            <div class="col-lg-4">
                                <div class="item main-bg position-re o-hidden md-mb50">
                                    <div class="info-box pb-30 bord-thin-bottom mb-30">
                                        <h6 class="sub-title mb-15">Basic Plan</h6>
                                        <div class="amount">
                                            <div><span class="main-color3 num-font fw-600 fz-50">$19</span> <span class="fz-14 fw-400">/ Month</span></div>
                                        </div>
                                        <p class="fz-13">10% tax will be included after pricing.</p>
                                    </div>
                                    <ul class="rest">
                                        <li>10 hours of essential work</li>
                                        <li>Single user included</li>
                                        <li>Advertising</li>
                                        <li>Web development</li>
                                        <li>24/7 support</li>
                                    </ul>
                                    <a href="{{ route('contact-en') }}" class="butn butn-md butn-bord mt-30">
                                        <span>Get Started Now</span>
                                        <i class="ml-5"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z" fill="currentColor"></path>
                                            </svg></i>
                                    </a>
                                    <div class="bg-pattern bg-img opacity-1" data-background="assets/imgs/patterns/1.svg" style="background-image: url('assets/imgs/patterns/1.svg');"></div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="item main-bg position-re o-hidden md-mb50">
                                    <div class="info-box pb-30 bord-thin-bottom mb-30">
                                        <h6 class="sub-title mb-15">Premuim Plan</h6>
                                        <div class="amount">
                                            <div><span class="main-color3 num-font fw-600 fz-50">$49</span> <span class="fz-14 fw-400">/ Month</span></div>
                                        </div>
                                        <p class="fz-13">10% tax will be included after pricing.</p>
                                    </div>
                                    <ul class="rest">
                                        <li>10 hours of essential work</li>
                                        <li>Single user included</li>
                                        <li>Advertising</li>
                                        <li>Web development</li>
                                        <li>24/7 support</li>
                                    </ul>
                                    <a href="{{ route('contact-en') }}" class="butn butn-md butn-bg main-colorbg3 text-dark mt-30">
                                        <span>Get Started Now</span>
                                        <i class="ml-5"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z" fill="currentColor"></path>
                                            </svg></i>
                                    </a>
                                    <div class="bg-pattern bg-img opacity-3" data-background="assets/imgs/patterns/abstact-BG.png" style="background-image: url('assets/imgs/patterns/abstact-BG.png');"></div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="item main-bg position-re o-hidden md-mb50">
                                    <div class="info-box pb-30 bord-thin-bottom mb-30">
                                        <h6 class="sub-title mb-15">Basic Plan</h6>
                                        <div class="amount">
                                            <div><span class="main-color3 num-font fw-600 fz-50">$19</span> <span class="fz-14 fw-400">/ Month</span></div>
                                        </div>
                                        <p class="fz-13">10% tax will be included after pricing.</p>
                                    </div>
                                    <ul class="rest">
                                        <li>10 hours of essential work</li>
                                        <li>Single user included</li>
                                        <li>Advertising</li>
                                        <li>Web development</li>
                                        <li>24/7 support</li>
                                    </ul>
                                    <a href="{{ route('contact-en') }}" class="butn butn-md butn-bord mt-30">
                                        <span>Get Started Now</span>
                                        <i class="ml-5"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z" fill="currentColor"></path>
                                            </svg></i>
                                    </a>
                                    <div class="bg-pattern bg-img opacity-1" data-background="assets/imgs/patterns/1.svg" style="background-image: url('assets/imgs/patterns/1.svg');"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ==================== End Blog ==================== -->


            </main>


            <!-- ==================== Start Footer ==================== -->

            <footer class="sub-bg">
                <div class="footer-container">
                    <div class="container pb-80 pt-80 ontop">
                        <div class="call-box text-center mb-80">
                            <h2>
                                <a href="{{ route('contact-en') }}">Let's <span class="stroke"> Discuss</span></a>
                                <span class="arrow">
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z"
                                            fill="currentColor"></path>
                                    </svg>
                                </span>
                            </h2>
                        </div>
                        @include('english.layout.footer')
                    </div>
                    @include('english.layout.credit')
                </div>
            </footer>

            <!-- ==================== End Footer ==================== -->

        </div>
    </div>







    <!-- jQuery -->
    <script src="{{ asset('assets/js/jquery-3.6.0.min.js') }}" ></script>
    <script src="{{ asset('assets/js/jquery-migrate-3.4.0.min.js') }}" ></script>

    <!-- plugins -->
    <script src="{{ asset('assets/js/plugins.js') }}" ></script>

    <script src="{{ asset('assets/js/gsap.min.js') }}" ></script>
    <script src="{{ asset('assets/js/ScrollSmoother.min.js') }}" ></script>
    <script src="{{ asset('assets/js/ScrollTrigger.min.js') }}" ></script>
    <script src="{{ asset('assets/js/hscroll.js') }}" ></script>
    <script src="{{ asset('assets/js/smoother-script.js') }}" ></script>

    <!-- custom scripts -->
    <script src="{{ asset('assets/js/scripts.js') }}" ></script>

</body>


</html>
